/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package multmatriz;

/**
 *
 * @author tcadsilva
 */
public class MultiplicacaoMatrizes {

    public static void main(String[] args) {

        // Declaração da primeira matriz A (2x2)
        int[][] A = {
            {1, 2},
            {3, 4}
        };

        // Declaração da segunda matriz B (2x2)
        int[][] B = {
            {5, 6},
            {7, 8}
        };

        // Matriz C armazenará o resultado da multiplicação
        int[][] C = new int[2][2];

        // Realiza a multiplicação das matrizes
        // Regra: linha da matriz A × coluna da matriz B
        for (int i = 0; i < 2; i++) {

            for (int j = 0; j < 2; j++) {

                for (int k = 0; k < 2; k++) {

                    C[i][j] += A[i][k] * B[k][j];
                }
            }
        }

        // Exibe a matriz A
        System.out.println("Matriz A:");

        for (int i = 0; i < 2; i++) {
            for (int j = 0; j < 2; j++) {
                System.out.print(A[i][j] + "\t");
            }
            System.out.println();
        }

        // Exibe a matriz B
        System.out.println("\nMatriz B:");

        for (int i = 0; i < 2; i++) {
            for (int j = 0; j < 2; j++) {
                System.out.print(B[i][j] + "\t");
            }
            System.out.println();
        }

        // Exibe a matriz resultante C
        System.out.println("\nMatriz C = A x B:");

        for (int i = 0; i < 2; i++) {
            for (int j = 0; j < 2; j++) {
                System.out.print(C[i][j] + "\t");
            }
            System.out.println();
        }
    }
}