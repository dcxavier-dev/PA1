/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package numeropor.matriz;

/**
 *
 * @author tcadsilva
 */
import javax.swing.JOptionPane;

public class MultiplicacaoMatrizEscalar {
    public static void main(String[] args) {
        try {
            // Ler o número (escalar)
            String inputEscalar = JOptionPane.showInputDialog("Digite o número (escalar) para multiplicar:");
            if (inputEscalar == null) return; // Cancela se fechar a janela
            double escalar = Double.parseDouble(inputEscalar);

            // Criar matriz 2x2
            double[][] matriz = new double[2][2];
            double[][] resultado = new double[2][2];

            // Ler os elementos da matriz 2x2
            for (int i = 0; i < 2; i++) {
                for (int j = 0; j < 2; j++) {
                    String val = JOptionPane.showInputDialog("Digite o elemento da posição [" + i + "][" + j + "]:");
                    if (val == null) return;
                    matriz[i][j] = Double.parseDouble(val);
                }
            }

            // Multiplicar o número por cada elemento da matriz
            StringBuilder saida = new StringBuilder("Matriz Resultante:\n");
            for (int i = 0; i < 2; i++) {
                for (int j = 0; j < 2; j++) {
                    resultado[i][j] = matriz[i][j] * escalar;
                    saida.append(resultado[i][j]).append("  ");
                }
                saida.append("\n");
            }

            // Exibir o resultado
            JOptionPane.showMessageDialog(null, saida.toString());

        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Por favor, digite apenas números válidos!", "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }
}